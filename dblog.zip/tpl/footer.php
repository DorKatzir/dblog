        <footer>
            <h5>
                <span>
                &copy <?= date('Y'); ?>&nbsp;dBlog -
                </span>

               <span>
                Special thanks to my mentor: Shlomi Lahav -
               </span>
               
               <span>
                Image: wallpaperswide.com 
               </span>
            </h5>
        </footer>

     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js">
     </script>
     <script src="js/jq.js" type="text/javascript"></script>
    </body>

</html>

