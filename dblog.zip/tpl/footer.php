        <footer>
            <h3>&copy <?= date('Y'); ?>&nbsp;dBlog &nbsp; | &nbsp; Special thanks to: Shlomi Lahav &nbsp; | &nbsp; Image: wallpaperswide.com </h3>
        </footer>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js">
     </script>
     <script src="js/jq.js" type="text/javascript"></script>
    </body>

</html>

