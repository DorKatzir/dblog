$('div.sm-box').delay(3000).slideUp();

